n1 = 1.44;
n2 = 3.476;
duty_cycle = 0.5;
neq_1 = sqrt(duty_cycle*n1^2+(1-duty_cycle)*n2^2)
